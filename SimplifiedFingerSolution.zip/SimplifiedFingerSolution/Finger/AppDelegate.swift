//
//  AppDelegate.swift
//  Finger
//
//  Created by Bene Terhechte on 08.06.18.
//  Copyright © 2018 Bene Terhechte. All rights reserved.
//

import Cocoa

@objc public final class CCApplication: NSApplication {
    @objc func _crashOnException(_ exception: NSException) {
        print("exception: \(exception)")
    }
}

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!

    override init() {
        ValueTransformer.setValueTransformer(FlagsValueTransformer(), forName: NSValueTransformerName(rawValue: "FlagsValueTransformer"))
        ValueTransformer.setValueTransformer(HideEmptySelectionValueTransformer(), forName: NSValueTransformerName(rawValue: "IsEmptySelection"))
        ValueTransformer.setValueTransformer(ValueToColorTransformer(colors: [false: .black, true: .lightGray]), forName: NSValueTransformerName(rawValue: "falseLightGrayColor"))
        ValueTransformer.setValueTransformer(ValueToColorTransformer<String>(colors: ["Updated": .red, "Reviewing": .systemBlue, "Marked": .orange, "Seen": .green]), forName: NSValueTransformerName(rawValue: "StatusToColor"))
        super.init()
    }
}

