import Foundation
import AppKit.NSColor

final class FlagsValueTransformer: ValueTransformer {
    override class func transformedValueClass() -> AnyClass {
        return NSString.self
    }
    
    override class func allowsReverseTransformation() -> Bool {
        return true
    }
    
    override func transformedValue(_ value: Any?) -> Any? {
        guard let v = value as? [String] else { return nil }
        return String(v.joined(separator: " "))
    }
    
    override func reverseTransformedValue(_ value: Any?) -> Any? {

        guard let v = value as? String else { return nil }
        return v.split(separator: " ")
    }
}

final class HideEmptySelectionValueTransformer: ValueTransformer {
    override class func transformedValueClass() -> AnyClass {
        return NSNumber.self
    }
    
    override class func allowsReverseTransformation() -> Bool {
        return false
    }
    
    override func transformedValue(_ value: Any?) -> Any? {
        guard let v = value as? NSIndexSet else { return nil }
        return NSNumber(booleanLiteral: v.count == 0)
    }    
}

final class ValueToColorTransformer<T>: ValueTransformer where T: Hashable {

    private let colors: [T: NSColor]
    
    init(colors: [T: NSColor]) {
        self.colors = colors
    }
    
    override class func transformedValueClass() -> AnyClass {
        return NSColor.self
    }
    
    override class func allowsReverseTransformation() -> Bool {
        return false
    }
    
    override func transformedValue(_ value: Any?) -> Any? {
        guard let v = value as? T else { return nil }
        return colors[v]
    }
}
